### Master thesis
#### Title:
Merged Spark and Hadoop API for minimal algorithms.

#### Author:
Mateusz Kiebala

#### Creating package
1. Set `SRC` path in `build.sh`
2. Run `./build.sh` in main directory.
