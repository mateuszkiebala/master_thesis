java -jar ../lib/avro-tools-1.8.1.jar help
java -jar ../lib/avro-tools-1.8.1.jar getmeta input.avro
java -jar ../lib/avro-tools-1.8.1.jar tojson input.avro

