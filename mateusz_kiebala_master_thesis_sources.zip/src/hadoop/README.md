### Master thesis
#### Title:
A Hadoop library for implementing minimal algorithms.

#### Author:
Mateusz Kiebala

#### Creating package
Run `mvn package` in main directory.

#### Examples
Edit file `settings.sh` and then go to selected example directory and run script `run.sh`