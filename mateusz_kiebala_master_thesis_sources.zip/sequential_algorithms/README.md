## Implementation of sequential version of minimal algorithms

### Build
```mvn compile```

### Run

Example of running TeraSort algorithm.

```mvn -q exec:java -Dexec.mainClass=sequential_algorithms.TeraSort```

